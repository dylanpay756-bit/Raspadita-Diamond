import os, sqlite3, secrets, random
from datetime import datetime
from zoneinfo import ZoneInfo
from functools import wraps
from flask import Flask, g, request, redirect, url_for, session, flash, render_template, abort

app = Flask(__name__)
app.secret_key = os.environ.get("RD_SECRET_KEY", "CAMBIAR-ESTA-CLAVE-ANTES-DE-PUBLICAR")
DB_PATH = os.environ.get("RD_DB_PATH", "red_diamond.sqlite3")
ADMIN_PASSWORD = os.environ.get("RD_ADMIN_PASSWORD", "CAMBIAR-ANTES-DE-PUBLICAR")
TZ = ZoneInfo("America/Argentina/Buenos_Aires")

# Probabilidades iniciales por casillero (ajustables):
# 5/19 = 10%, 3/19 = 20%, 2/19 = 30%, 1/19 = 10.000 fichas, 8/19 = vacío.
PRIZE_POOL = ["10%"] * 5 + ["20%"] * 3 + ["30%"] * 2 + ["10000"] + ["VACIO"]

def today():
    return datetime.now(TZ).date().isoformat()

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=30)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    conn = g.pop("db", None)
    if conn:
        conn.close()

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT UNIQUE NOT NULL,
            customer TEXT NOT NULL,
            customer_key TEXT NOT NULL,
            created_day TEXT NOT NULL,
            revealed1 INTEGER NOT NULL DEFAULT 0,
            revealed2 INTEGER NOT NULL DEFAULT 0,
            prize1 TEXT,
            prize2 TEXT
        )
    """)
    conn.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS one_ticket_per_customer_day
        ON tickets(customer_key, created_day)
    """)
    conn.commit()
    conn.close()

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def revealed_star_count(conn, day):
    row = conn.execute("""
        SELECT
          COALESCE(SUM(CASE WHEN prize1='10000' AND revealed1=1 THEN 1 ELSE 0 END),0) +
          COALESCE(SUM(CASE WHEN prize2='10000' AND revealed2=1 THEN 1 ELSE 0 END),0)
        FROM tickets WHERE created_day=?
    """, (day,)).fetchone()
    return row[0] or 0

def choose_prize(conn, day):
    prize = random.choice(PRIZE_POOL)
    if prize == "10000" and revealed_star_count(conn, day) >= 5:
        return "VACIO"
    return prize

@app.route("/")
def home():
    return redirect(url_for("admin"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        supplied = request.form.get("password", "")
        if secrets.compare_digest(supplied, ADMIN_PASSWORD):
            session.clear()
            session["admin"] = True
            return redirect(url_for("admin"))
        flash("Contraseña incorrecta.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/admin")
@admin_required
def admin():
    conn = get_db()
    day = today()
    rows = conn.execute("SELECT * FROM tickets ORDER BY id DESC LIMIT 100").fetchall()
    stars = revealed_star_count(conn, day)
    return render_template("admin.html", rows=rows, stars=stars, day=day)

@app.route("/create", methods=["POST"])
@admin_required
def create_ticket():
    customer = request.form.get("customer", "").strip()
    customer_key = request.form.get("customer_key", "").strip()
    if not customer or not customer_key:
        flash("Completá el nombre y el teléfono/identificador del cliente.")
        return redirect(url_for("admin"))

    day = today()
    token = secrets.token_urlsafe(24)
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO tickets(token, customer, customer_key, created_day) VALUES(?,?,?,?)",
            (token, customer, customer_key, day)
        )
        conn.commit()
    except sqlite3.IntegrityError:
        flash("Ese cliente ya tiene una raspadita creada hoy.")
        return redirect(url_for("admin"))

    link = request.url_root.rstrip("/") + url_for("scratch", token=token)
    return render_template("created.html", customer=customer, link=link)

@app.route("/r/<token>")
def scratch(token):
    ticket = get_db().execute("SELECT * FROM tickets WHERE token=?", (token,)).fetchone()
    if not ticket:
        abort(404)
    return render_template("scratch.html", ticket=ticket)

@app.route("/r/<token>/reveal/<int:slot>", methods=["POST"])
def reveal(token, slot):
    if slot not in (1, 2):
        abort(404)
    conn = get_db()
    # Serializa la operación para evitar superar el tope diario con solicitudes simultáneas.
    conn.execute("BEGIN IMMEDIATE")
    ticket = conn.execute("SELECT * FROM tickets WHERE token=?", (token,)).fetchone()
    if not ticket:
        conn.rollback()
        abort(404)

    revealed_col = f"revealed{slot}"
    prize_col = f"prize{slot}"
    if ticket[revealed_col]:
        prize = ticket[prize_col]
        conn.commit()
    else:
        prize = choose_prize(conn, ticket["created_day"])
        conn.execute(
            f"UPDATE tickets SET {revealed_col}=1, {prize_col}=? WHERE id=?",
            (prize, ticket["id"])
        )
        conn.commit()

    return render_template("result.html", prize=prize, slot=slot, token=token)

@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
