RED DIAMOND - RASPADITA DIGITAL
Base técnica para pruebas y posterior despliegue. NO está publicada en internet.

FUNCIONES
- Panel protegido por contraseña compartida.
- Alta manual de clientes y creación de enlace individual.
- Un ticket por identificador de cliente y día (fecha de Argentina).
- Dos casilleros por ticket; cada uno se revela una sola vez.
- Máximo de cinco premios de 10.000 fichas revelados por día, compartido en la misma base de datos.
- Premios: 10%, 20%, 30%, 10.000 fichas o vacío.
- El cajero valida manualmente la primera carga diaria antes de crear el ticket.
- Los premios se acreditan manualmente; este prototipo no mueve dinero ni saldo de cuentas.

PROBABILIDADES INICIALES
En cada casillero: 5/19 de 10%, 3/19 de 20%, 2/19 de 30%, 1/19 de 10.000 fichas y 8/19 vacío.
Se modifican en PRIZE_POOL dentro de app.py. Revisar y aprobar estas probabilidades antes de cualquier campaña.

PRUEBA LOCAL
1. Instalar Python 3.11 o superior.
2. Abrir una terminal en esta carpeta.
3. Crear y activar entorno virtual:
   python -m venv .venv
4. Instalar dependencias:
   pip install -r requirements.txt
5. Definir variables de entorno RD_ADMIN_PASSWORD y RD_SECRET_KEY con valores fuertes.
   También se puede definir RD_DB_PATH para ubicar la base de datos.
6. Ejecutar:
   python app.py
7. Abrir http://localhost:5000/login

PUBLICACIÓN
Para que los cajeros y clientes accedan desde sus teléfonos se necesita hosting, dominio/URL pública, HTTPS y una base de datos persistente compartida. Si se usan varios servidores o procesos, migrar SQLite a PostgreSQL.
No publicar con claves de prueba. Antes de producción agregar protección CSRF, límites de intentos, auditoría por cajero, copias de seguridad y pruebas de concurrencia.
La contraseña compartida no permite identificar qué cajero creó cada ticket. Para auditoría real, conviene crear usuarios individuales.


PUBLICACIÓN GUIADA EN RENDER
Se agregó render.yaml para configurar un servicio Python con disco persistente.
El plan Starter y el disco persistente pueden tener costo; revisar el precio vigente antes de confirmar.
1. Crear una cuenta en Render y un repositorio privado en GitHub.
2. Subir el contenido de esta carpeta al repositorio (no subir contraseñas).
3. En Render, elegir New > Blueprint y conectar el repositorio.
4. Render leerá render.yaml. Al pedir RD_ADMIN_PASSWORD, ingresar una contraseña fuerte y única.
5. Revisar el costo del servicio y disco persistente antes de confirmar la creación.
6. Cuando termine el deploy, Render mostrará una URL pública *.onrender.com.
7. Probar el acceso, creación de ticket y revelación de casilleros antes de compartirla.

IMPORTANTE: No ingreses contraseñas bancarias ni compartas claves privadas en el chat.
El usuario debe crear y controlar sus propias cuentas de GitHub y Render.
